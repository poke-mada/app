/* eslint-disable no-undef */
// noinspection JSUnresolvedVariable

import {COVERAGE_DATA} from '@/data/type_data';
import {MOVE_DATA} from '@/data/move_data';
import {FORCE_TYPE_ABILITIES, SPECIAL_MOVES} from '@/data/force_type_data';

function Movement(item_held, ability, slot, move_id) {
    if (move_id === 0) return;

    let move = MOVE_DATA[move_id];
    if (!move) {
        return {
            discovered: false,
            slot: slot,
            move_name: '',
            description: '',
            current_pp: 0,
            max_pp: 0,
            type: '',
            power: 0,
            accuracy: 0,
            category: '',
            coverage_data: {
                double_damage_to: [],
                half_damage_to: [],
                no_damage_to: []
            },
            moves: [
                {
                    id: 0x5A,
                    pp: 0x62
                },
                {
                    id: 0x5C,
                    pp: 0x63
                },
                {
                    id: 0x5E,
                    pp: 0x64
                },
                {
                    id: 0x60,
                    pp: 0x65
                }
            ],
            status: 0xE8,
            current_hp: 0xF0,
            max_hp: 0xF2
        };
    }

    let move_type = move.typename;

    if (move_id in SPECIAL_MOVES) {
        let special_move = SPECIAL_MOVES[move_id];
        if (item_held in special_move) {
            move_type = special_move[item_held];
        }
    }

    let forced_type = ability.toString() in FORCE_TYPE_ABILITIES;
    if (forced_type) {
        let ability_data = FORCE_TYPE_ABILITIES[ability];
        if (move_type === ability_data.forced_from) {
            move_type = ability_data.forced_type;
        } else if (ability_data.forced_from === '*') {
            move_type = ability_data.forced_type;
        }
    }


    let coverage_data = COVERAGE_DATA[move_type.toLowerCase()];
    return {
        slot: slot,
        move_name: move.movename,
        max_pp: move.movepp,
        type: move_type,
        power: move.movepower,
        accuracy: move.moveaccuracy,
        category: move.movecategoryname,
        flavor_text: move.falvor_text,
        coverage_data: coverage_data
    };

}

export {
    Movement
}